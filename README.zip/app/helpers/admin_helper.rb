module AdminHelper
end
