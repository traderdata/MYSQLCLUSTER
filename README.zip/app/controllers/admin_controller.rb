class AdminController < ApplicationController
  def dashboard
    @title = "Dashboard"
    @title2="Dashboard"
  end
end
