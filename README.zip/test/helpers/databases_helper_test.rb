require 'test_helper'

class DatabasesHelperTest < ActionView::TestCase
end
